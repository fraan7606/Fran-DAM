from modelo.cliente import Cliente

class ClienteControlador:
    def __init__(self):


    def agregar_cliente(self, nombre, dni, telefono):

        nuevo = Cliente(len(self.clientes) + 1, nombre, dni, telefono)
        self.clientes.append(nuevo)

        return nuevo
    """Crea y agrega un nuevo cliente"""

    def obtener_clientes(self):
        return self.clientes

    """Devuelve la lista de clientes"""

    def buscar_cliente_por_id(self, id_cliente):
        for cliente in self.clientes:
            if cliente.id_cliente == id_cliente:
                return cliente
        return None

    def registrar_pago(self, id_cliente):
        cliente = self.buscar_cliente_por_id(id_cliente)
        if cliente:
            cliente.pagado = True
            return True
        return False
    """Marca los clientes que han pagado"""


    def obtener_nopagados(self):
        return [c for c in self.clientes if not c.pagado]
    """Devuelve la lista de clientes que no han pagado la cuota"""
