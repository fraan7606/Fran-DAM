from modelo.reserva import Reserva

class ReservaControlador:
    def __init__(self):
        self.reservas = []

    def agregar_reserva(self, cliente, aparato, dia, hora):
        # Verificar disponibilidad
        for r in self.reservas:
            if (r.aparato.id_aparato == aparato.id_aparato
                and r.dia.lower() == dia.lower()
                and r.hora == hora):
                return None  # Aparato ocupado

        nueva = Reserva(len(self.reservas) + 1, cliente, aparato, dia, hora)
        self.reservas.append(nueva)
        return nueva
    """Agrega una nueva reserva si el aparato está disponible"""

    def obtener_reservas(self):
        return self.reservas
    """Devuelve todas las reservas"""

    def obtener_reservas_por_dia(self, dia):
        return [r for r in self.reservas if r.dia.lower() == dia.lower()]
    """Devuelve reservas de un día concreto"""
