from modelo.aparato import Aparato

class AparatoControlador:
    def __init__(self):
        self.aparatos = []

    def agregar_aparato(self, nombre, tipo):
        nuevo = Aparato(len(self.aparatos) + 1, nombre, tipo)
        self.aparatos.append(nuevo)
        return nuevo
    """Agrega un nuevo aparato"""

    def obtener_aparatos(self):
        return self.aparatos
    """Devuelve la lista de aparatos"""

    def buscar_aparato_por_id(self, id_aparato):
        for aparato in self.aparatos:
            if aparato.id_aparato == id_aparato:
                return aparato
        return None
    """Busca un aparato por su ID"""
