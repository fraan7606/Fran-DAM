class Cliente:
    def __init__(self, id_cliente, nombre, dni, telefono):
        self.id_cliente = id_cliente
        self.nombre = nombre
        self.dni = dni
        self.telefono = telefono
        self.pagado = False

    def __str__(self):
        estado = "Pagado" if self.pagado else "Pendiente"
        return f"[{self.id_cliente}] {self.nombre} ({self.dni}) - {estado}"
