class Reserva:
    def __init__(self, id_reserva, cliente, aparato, dia, hora):
        self.id_reserva = id_reserva
        self.cliente = cliente
        self.aparato = aparato
        self.dia = dia
        self.hora = hora

    def __str__(self):
        return f"Reserva {self.id_reserva}: {self.dia} {self.hora} - {self.aparato.nombre} (Cliente: {self.cliente.nombre})"
