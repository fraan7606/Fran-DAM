class Aparato:
    def __init__(self, id_aparato, nombre, tipo):
        self.id_aparato = id_aparato
        self.nombre = nombre
        self.tipo = tipo

    def __str__(self):
        return f"[{self.id_aparato}] {self.nombre} ({self.tipo})"
