from datetime import date

class Pagos:
    def __init__(self, id_pago, cliente, monto, fecha_pago=None, pagado=False):
        self.id_pago = id_pago
        self.cliente = cliente
        self.monto = monto
        self.fecha_pago = fecha_pago
        self.pagado = pagado

    def registrar_pago(self):
        """Marca el pago como realizado con la fecha actual."""
        self.pagado = True
        self.fecha_pago = date.today()

    def __str__(self):
        estado = "Pagado" if self.pagado else "Pendiente"
        fecha = self.fecha_pago.strftime("%d/%m/%Y") if self.fecha_pago else "—"
        return f"Pago {self.id_pago}: Cliente: {self.cliente.nombre} | Monto: {self.monto}€ | Estado: {estado} | Fecha: {fecha}"
