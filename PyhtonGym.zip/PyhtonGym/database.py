import sqlite3

# --------------------------
# Función para conectar
# --------------------------
def conectar():
    """Crea y devuelve la conexión con la base de datos del proyecto PythonGym"""
    conexion = sqlite3.connect("pythongym.db")
    return conexion

# --------------------------
# Crear las tablas si no existen
# --------------------------
def crear_tablas():
    conexion = conectar()
    cursor = conexion.cursor()

    # Tabla Clientes
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS cliente (
        id_cliente INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        apellido TEXT NOT NULL,
        edad INTEGER,
        genero TEXT,
        telefono TEXT,
        email TEXT,
        pagado BOOLEAN DEFAULT 0
    )
    """)

    # Tabla Aparatos
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS aparato (
        id_aparato INTEGER PRIMARY KEY AUTOINCREMENT,
        tipo TEXT NOT NULL,
        estado TEXT NOT NULL
    )
    """)

    # Tabla Reservas
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS reserva (
        id_reserva INTEGER PRIMARY KEY AUTOINCREMENT,
        id_cliente INTEGER,
        id_aparato INTEGER,
        fecha TEXT NOT NULL,
        hora TEXT NOT NULL,
        FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente),
        FOREIGN KEY (id_aparato) REFERENCES aparato(id_aparato)
    )
    """)

    # Tabla Pagos
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS pago (
        id_pago INTEGER PRIMARY KEY AUTOINCREMENT,
        id_cliente INTEGER,
        monto REAL,
        fecha_pago TEXT,
        pagado BOOLEAN DEFAULT 0,
        FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
    )
    """)

    conexion.commit()
    conexion.close()
    print("Tablas creadas o verificadas correctamente (base de datos PythonGym).")

# Ejecutar directamente si se llama este archivo
if __name__ == "__main__":
    crear_tablas()

    if __name__ == "__main__":
        crear_tablas()

        # Conexión e inserciones de ejemplo
        conexion = conectar()
        cursor = conexion.cursor()

        clientes = [
            ("Ana", "López", 28, "Femenino", "666111222", "ana@example.com"),
            ("Carlos", "Martín", 35, "Masculino", "666333444", "carlos@example.com"),
            ("Lucía", "García", 22, "Femenino", "666555666", "lucia@example.com"),
        ]

        cursor.executemany("""
            INSERT INTO cliente (nombre, apellido, edad, genero, telefono, email)
            VALUES (?, ?, ?, ?, ?, ?)
        """, clientes)

        conexion.commit()
        conexion.close()
        print("✅ Clientes de ejemplo insertados correctamente en PythonGym.")




