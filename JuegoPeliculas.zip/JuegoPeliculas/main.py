import tkinter as tk
from juego_gui import JuegoGUI

if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("500x500")
    root.resizable(False, False)
    app = JuegoGUI(root)
    root.mainloop()
