import sqlite3
from pelicula import Pelicula
from datetime import datetime

class DBManager:
    def __init__(self, nombre_bd="peliculas.db"):
        self.nombre_bd = nombre_bd
        self.crear_tablas()

    def conectar(self):
        return sqlite3.connect(self.nombre_bd)

    def crear_tablas(self):
        conn = self.conectar()
        cursor = conn.cursor()

        # Tabla de películas
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS peliculas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                pista1 TEXT NOT NULL,
                pista2 TEXT NOT NULL,
                pista3 TEXT NOT NULL,
                pista4 TEXT NOT NULL,
                pista5 TEXT NOT NULL
            )
        """)

        # Tabla de partidas
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS partidas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fecha TEXT NOT NULL,
                puntuacion INTEGER NOT NULL
            )
        """)

        conn.commit()
        conn.close()

    def insertar_peliculas_iniciales(self):
        conn = self.conectar()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM peliculas")
        if cursor.fetchone()[0] == 0:
            peliculas = [
                ("Seven", "Dos detectives investigan asesinatos muy meticulosos", "Cada crimen está relacionado con los siete pecados capitales", "Uno de los detectives está por jubilarse", "El otro es joven e impulsivo", "¿Qué hay en la caja?"),
                ("Shutter Island", "Un investigador viaja a un lugar aislado", "Hay un hospital con pacientes peligrosos", "El protagonista duda de su propia mente", "Dirigida por Martin Scorsese", "Protagonizada por Leonardo DiCaprio"),
                ("La vida es bella", "Un hombre usa su imaginación para proteger a su hijo", "Transcurre durante la Segunda Guerra Mundial", "La risa es su arma ante el horror", "Ganó el Óscar a Mejor Película Extranjera", "Protagonizada por Roberto Benigni"),
                ("Origen", "Un grupo realiza misiones dentro de los sueños", "La realidad y el sueño se mezclan", "Una peonza tiene un significado especial", "Dirigida por Christopher Nolan", "Protagonizada por Leonardo DiCaprio"),
                ("El club de la lucha", "Un hombre sin nombre con insomnio", "Crea una organización secreta", "El jabón tiene un papel importante", "Dirigida por David Fincher", "Primera regla: no hablar de esto"),
            ]
            cursor.executemany("""
                INSERT INTO peliculas (titulo, pista1, pista2, pista3, pista4, pista5)
                VALUES (?, ?, ?, ?, ?, ?)
            """, peliculas)
            conn.commit()
        conn.close()

    def obtener_pelicula_aleatoria(self):
        conn = self.conectar()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT titulo, pista1, pista2, pista3, pista4, pista5
            FROM peliculas ORDER BY RANDOM() LIMIT 1
        """)
        fila = cursor.fetchone()
        conn.close()

        if fila:
            titulo = fila[0]
            pistas = list(fila[1:])
            return Pelicula(titulo, pistas)
        return None

    def guardar_partida(self, puntuacion):
        conn = self.conectar()
        cursor = conn.cursor()
        fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("INSERT INTO partidas (fecha, puntuacion) VALUES (?, ?)", (fecha, puntuacion))
        conn.commit()
        conn.close()

    def obtener_historial(self):
        conn = self.conectar()
        cursor = conn.cursor()
        cursor.execute("SELECT fecha, puntuacion FROM partidas ORDER BY id DESC")
        datos = cursor.fetchall()
        conn.close()
        return datos
