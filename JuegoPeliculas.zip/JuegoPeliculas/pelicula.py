class Pelicula:
    def __init__(self, titulo, pistas):
        self.titulo = titulo
        self.pistas = pistas

    def mostrar_pista(self, numero):
        """Devuelve la pista número (1-5)."""
        if 1 <= numero <= len(self.pistas):
            return self.pistas[numero - 1]
        return None
