import tkinter as tk
from tkinter import messagebox
from db_manager import DBManager

class JuegoGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("🎬 Adivina la Película")
        self.db = DBManager()
        self.db.insertar_peliculas_iniciales()
        self.pelicula = None
        self.puntaje = 30
        self.pista_numero = 0

        self.crear_menu()

    def limpiar_ventana(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def crear_menu(self):
        self.limpiar_ventana()
        tk.Label(self.root, text="🎬 Adivina la Película", font=("Arial", 20, "bold")).pack(pady=20)
        tk.Button(self.root, text="Jugar partida", command=self.iniciar_partida, width=20, height=2).pack(pady=10)
        tk.Button(self.root, text="Ver historial", command=self.ver_historial, width=20, height=2).pack(pady=10)
        tk.Button(self.root, text="Salir", command=self.root.quit, width=20, height=2).pack(pady=10)

    def iniciar_partida(self):
        self.limpiar_ventana()
        self.pelicula = self.db.obtener_pelicula_aleatoria()
        self.puntaje = 30
        self.pista_numero = 0

        tk.Label(self.root, text="Adivina la película o serie", font=("Arial", 16, "bold")).pack(pady=10)
        self.lbl_puntaje = tk.Label(self.root, text=f"Puntos: {self.puntaje}", font=("Arial", 14))
        self.lbl_puntaje.pack(pady=5)

        self.lbl_pista = tk.Label(self.root, text="", font=("Arial", 12), wraplength=400, justify="center")
        self.lbl_pista.pack(pady=10)

        self.entry_respuesta = tk.Entry(self.root, width=40, font=("Arial", 12))
        self.entry_respuesta.pack(pady=5)

        tk.Button(self.root, text="Pedir pista (-2 puntos)", command=self.mostrar_pista).pack(pady=5)
        tk.Button(self.root, text="Comprobar respuesta", command=self.comprobar_respuesta).pack(pady=5)
        tk.Button(self.root, text="Volver al menú", command=self.crear_menu).pack(pady=10)

    def mostrar_pista(self):
        if self.pista_numero < 5 and self.puntaje > 0:
            self.pista_numero += 1
            self.puntaje -= 2
            self.lbl_pista.config(text=f"Pista {self.pista_numero}: {self.pelicula.mostrar_pista(self.pista_numero)}")
            self.lbl_puntaje.config(text=f"Puntos: {self.puntaje}")
        else:
            messagebox.showinfo("Fin de pistas", "Ya no quedan más pistas.")

    def comprobar_respuesta(self):
        respuesta = self.entry_respuesta.get().strip().lower()
        if respuesta == self.pelicula.titulo.lower():
            messagebox.showinfo("¡Correcto!", f"Era '{self.pelicula.titulo}'.\nPuntuación final: {self.puntaje}")
            self.db.guardar_partida(self.puntaje)
            self.crear_menu()
        else:
            if self.puntaje <= 0 or self.pista_numero >= 5:
                messagebox.showinfo("Fin del juego", f"Te has quedado sin puntos.\nEra '{self.pelicula.titulo}'.")
                self.db.guardar_partida(self.puntaje)
                self.crear_menu()
            else:
                messagebox.showwarning("Incorrecto", "No es correcto, prueba otra vez.")

    def ver_historial(self):
        self.limpiar_ventana()
        tk.Label(self.root, text="📜 Historial de partidas", font=("Arial", 18, "bold")).pack(pady=10)

        partidas = self.db.obtener_historial()
        if not partidas:
            tk.Label(self.root, text="Aún no has jugado ninguna partida.").pack(pady=10)
        else:
            for fecha, puntuacion in partidas:
                tk.Label(self.root, text=f"{fecha} — {puntuacion} puntos", font=("Arial", 12)).pack()

        tk.Button(self.root, text="Volver al menú", command=self.crear_menu).pack(pady=20)
