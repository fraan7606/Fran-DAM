package estructuras;

class NodoPila {
    char dato;
    NodoPila siguiente;

    NodoPila(char d) {
        dato = d;
        siguiente = null;
    }
}

public class Pila {
    private NodoPila cima;

    public Pila() {
        cima = null;
    }

    public void push(char c) {
        NodoPila nuevo = new NodoPila(c);
        nuevo.siguiente = cima;
        cima = nuevo;
    }

    public char pop() {
        if (isEmpty()) throw new RuntimeException("Pila vacía");
        char valor = cima.dato;
        cima = cima.siguiente;
        return valor;
    }

    public boolean isEmpty() {
        return cima == null;
    }
}
