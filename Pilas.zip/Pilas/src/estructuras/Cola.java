package estructuras;

class NodoCola {
    String dato;
    NodoCola siguiente;

    NodoCola(String d) {
        dato = d;
        siguiente = null;
    }
}

public class Cola {
    private NodoCola frente, fin;

    public Cola() {
        frente = fin = null;
    }

    public void encolar(String d) {
        NodoCola nuevo = new NodoCola(d);
        if (fin != null)
            fin.siguiente = nuevo;
        fin = nuevo;
        if (frente == null)
            frente = nuevo;
    }

    public String desencolar() {
        if (isEmpty()) throw new RuntimeException("Cola vacía");
        String valor = frente.dato;
        frente = frente.siguiente;
        if (frente == null) fin = null;
        return valor;
    }

    public boolean isEmpty() {
        return frente == null;
    }

    public void mostrar() {
        if (isEmpty()) {
            System.out.println("La cola está vacía.");
            return;
        }
        System.out.println("Estado actual de la cola:");
        NodoCola aux = frente;
        while (aux != null) {
            System.out.print(aux.dato + " ");
            aux = aux.siguiente;
        }
        System.out.println();
    }
}
