import ejercicios.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n====== MENÚ PRINCIPAL ======");
            System.out.println("1) Invertir texto (Pila)");
            System.out.println("2) Simular cola de clientes (Cola)");
            System.out.println("3) Verificar palíndromo (Pila y Cola)");
            System.out.println("4) Decimal a binario (Pila)");
            System.out.println("5) Salir");
            System.out.print("Selecciona una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> Ejercicio1.ejecutar();
                case 2 -> Ejercicio2.ejecutar();
                case 3 -> Ejercicio3.ejecutar();
                case 4 -> Ejercicio4.ejecutar();
                case 5 -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Opción no válida.");
            }

        } while (opcion != 5);
    }
}
