package ejercicios;

import estructuras.Cola;
import java.util.Scanner;

public class Ejercicio2 {
    public static void ejecutar() {
        Scanner sc = new Scanner(System.in);
        Cola cola = new Cola();
        int opcion;

        do {
            System.out.println("\n--- MENÚ COLA DE CLIENTES ---");
            System.out.println("1) Llegada");
            System.out.println("2) Atender");
            System.out.println("3) Mostrar cola");
            System.out.println("4) Volver al menú principal");
            System.out.print("Opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> {
                    System.out.print("Nombre del cliente: ");
                    String nombre = sc.nextLine();
                    cola.encolar(nombre);
                    System.out.println("Cliente añadido a la cola.");
                }
                case 2 -> {
                    if (!cola.isEmpty())
                        System.out.println("Atendiendo a: " + cola.desencolar());
                    else
                        System.out.println("No hay clientes en la cola.");
                }
                case 3 -> cola.mostrar();
                case 4 -> System.out.println("Volviendo al menú principal...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 4);
    }
}
