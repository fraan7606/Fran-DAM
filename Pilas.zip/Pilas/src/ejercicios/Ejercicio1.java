package ejercicios;

import estructuras.Pila;
import java.util.Scanner;

public class Ejercicio1 {
    public static void ejecutar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce un texto: ");
        String texto = sc.nextLine();

        Pila pila = new Pila();

        for (char c : texto.toCharArray()) {
            pila.push(c);
        }

        String invertido = "";
        while (!pila.isEmpty()) {
            invertido += pila.pop();
        }

        System.out.println("Texto invertido: " + invertido);
    }
}


