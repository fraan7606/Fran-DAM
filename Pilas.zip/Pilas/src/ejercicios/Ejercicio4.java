package ejercicios;

import estructuras.Pila;
import java.util.Scanner;

public class Ejercicio4 {
    public static void ejecutar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce un número entero positivo: ");
        int numero = sc.nextInt();

        if (numero == 0) {
            System.out.println("Binario: 0");
            return;
        }

        Pila pila = new Pila();

        while (numero > 0) {
            int resto = numero % 2;
            pila.push((char) (resto + '0'));
            numero /= 2;
        }

        String binario = "";
        while (!pila.isEmpty()) {
            binario += pila.pop();
        }

        System.out.println("Binario: " + binario);
    }
}
