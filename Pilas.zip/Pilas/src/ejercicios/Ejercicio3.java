package ejercicios;

import estructuras.Pila;
import estructuras.Cola;
import java.util.Scanner;

public class Ejercicio3 {
    public static void ejecutar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("\nIntroduce una palabra o frase: ");
        String texto = sc.nextLine().toLowerCase().replaceAll("\\s+", "");

        Pila pila = new Pila();
        Cola cola = new Cola();

        for (char c : texto.toCharArray()) {
            pila.push(c);
            cola.encolar(String.valueOf(c));
        }

        boolean esPalindromo = true;
        while (!pila.isEmpty()) {
            char desdePila = pila.pop();
            char desdeCola = cola.desencolar().charAt(0);
            if (desdePila != desdeCola) {
                esPalindromo = false;
                break;
            }
        }

        if (esPalindromo)
            System.out.println("Es un palíndromo.");
        else
            System.out.println("No es un palíndromo.");
    }
}
