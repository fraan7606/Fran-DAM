﻿using System;
using System.Globalization;


    public sealed class GastoExtra : Gasto
    {
        public bool Prescindible { get; }

        public GastoExtra(decimal cantidad, string descripcion, bool prescindible, DateTime? fecha = null) : base(cantidad, descripcion, fecha)
        {
            Prescindible = prescindible;
        }

        public override string ToString()
        {
            var tag = Prescindible ? "prescindible" : "no prescindible";
            return $"Gasto extra ({tag}): {Descripcion}, -{Cantidad.ToString("N2", new CultureInfo("es-ES"))}€ ({Fecha:yyyy-MM-dd})";
        }
    }

