﻿using System;
using System.Globalization;
using System.Linq;                 // <-- AÑADIR



public class Program
{
    
    
        static string Prompt(string msg)
        {
            Console.Write(msg);
            var s = Console.ReadLine();
            return s == null ? "" : s.Trim();
        }

        static decimal ReadMoney(string msg)
        {
            while (true)
            {
                var s = Prompt(msg);
                if (string.IsNullOrWhiteSpace(s)) s = "0";
                s = s.Replace(',', '.');
                if (decimal.TryParse(s, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var v) && v >= 0) return v;
                Console.WriteLine("Valor inválido.");
            }
        }

        static DateTime ReadDate(string msg)
        {
            while (true)
            {
                var s = Prompt(msg);
                if (DateTime.TryParse(s, new CultureInfo("es-ES"), DateTimeStyles.None, out var d)) return d;
                Console.WriteLine("Fecha inválida. Usa formato dd/mm/aaaa o similar.");
            }
        }

        static void Main(string[] args)
        {
            Console.Write("Introduce tu nombre: ");
            var nombre = Console.ReadLine()?.Trim() ?? "";
            Console.Write("Introduce tu edad: ");
            var edadStr = Console.ReadLine();
            int.TryParse(edadStr, out var edad);
            var usuario = new Usuario(nombre, edad);

            while (true)
            {
                var dni = Prompt("Introduce tu DNI (8 números y una letra, ej: 12345678A): ");
                if (usuario.SetDni(dni)) break;
                Console.WriteLine("DNI no válido. Intenta de nuevo.");
            }

            var cuenta = new Cuenta(usuario);
            usuario.SetCuenta(cuenta);
            var wishlist = new Wishlist(usuario);

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("Realiza una nueva acción");
                Console.WriteLine("1 Introduce un nuevo gasto básico");
                Console.WriteLine("2 Introduce un nuevo gasto extra");
                Console.WriteLine("3 Introduce un nuevo ingreso");
                Console.WriteLine("4 Mostrar gastos");
                Console.WriteLine("5 Mostrar ingresos");
                Console.WriteLine("6 Mostrar saldo");
                Console.WriteLine("7 Mostrar ahorro de un período");
                Console.WriteLine("8 Mostrar gastos imprescindibles");
                Console.WriteLine("9 Mostrar posibles ahorros del mes pasado");
                Console.WriteLine("10 Mostrar lista de deseos");
                Console.WriteLine("11 Mostrar productos que podemos comprar");
                Console.WriteLine("0 Salir");

                var opcion = Prompt("Selecciona una opción: ");

                if (opcion == "1")
                {
                    var cantidad = ReadMoney("Cantidad del gasto básico: ");
                    var desc = Prompt("Descripción: ");
                    try
                    {
                        cuenta.AddGastoBasico(cantidad, desc);
                        Console.WriteLine("Gasto básico añadido.");
                    }
                    catch (GastoException e)
                    {
                        Console.WriteLine($"Error: {e.Message}");
                    }
                }
                else if (opcion == "2")
                {
                    var cantidad = ReadMoney("Cantidad del gasto extra: ");
                    var desc = Prompt("Descripción: ");
                    var pres = Prompt("¿Es prescindible? (s/n): ").ToLowerInvariant().StartsWith("s");
                    try
                    {
                        cuenta.AddGastoExtra(cantidad, desc, pres);
                        Console.WriteLine("Gasto extra añadido.");
                    }
                    catch (GastoException e)
                    {
                        Console.WriteLine($"Error: {e.Message}");
                    }
                }
                else if (opcion == "3")
                {
                    var cantidad = ReadMoney("Cantidad del ingreso: ");
                    var desc = Prompt("Descripción: ");
                    cuenta.AddIngreso(cantidad, desc);
                    Console.WriteLine("Ingreso añadido.");
                }
                else if (opcion == "4")
                {
                    Console.WriteLine("1 Totales  2 Básicos  3 Extras");
                    var tipo = Prompt("Elige tipo: ");
                    var esteMes = Prompt("¿Solo este mes? (s/n): ").ToLowerInvariant().StartsWith("s");
                    if (tipo == "1")
                    {
                        var gastos = cuenta.GetGastosBasicos(esteMes).Cast<Gasto>().Concat(cuenta.GetGastosExtras(esteMes)).OrderBy(g => g.Fecha).ToList();
                        if (gastos.Count == 0) Console.WriteLine("Sin gastos.");
                        foreach (var g in gastos) Console.WriteLine(g.ToString());
                    }
                    else if (tipo == "2")
                    {
                        var gastos = cuenta.GetGastosBasicos(esteMes);
                        if (gastos.Count == 0) Console.WriteLine("Sin gastos básicos.");
                        foreach (var g in gastos) Console.WriteLine(g.ToString());
                    }
                    else if (tipo == "3")
                    {
                        var gastos = cuenta.GetGastosExtras(esteMes);
                        if (gastos.Count == 0) Console.WriteLine("Sin gastos extras.");
                        foreach (var g in gastos) Console.WriteLine(g.ToString());
                    }
                    else
                    {
                        Console.WriteLine("Opción no válida.");
                    }
                }
                else if (opcion == "5")
                {
                    var esteMes = Prompt("¿Solo este mes? (s/n): ").ToLowerInvariant().StartsWith("s");
                    var ingresos = cuenta.GetIngresos(esteMes);
                    if (ingresos.Count == 0) Console.WriteLine("Sin ingresos.");
                    foreach (var i in ingresos) Console.WriteLine(i.ToString());
                }
                else if (opcion == "6")
                {
                    Console.WriteLine($"Saldo actual: {cuenta.Saldo.ToString("N2", new CultureInfo("es-ES"))}€");
                }
                else if (opcion == "7")
                {
                    var d1 = ReadDate("Fecha inicio (ej 01/09/2025): ");
                    var d2 = ReadDate("Fecha fin (ej 30/09/2025): ");
                    if (d2 < d1) { var t = d1; d1 = d2; d2 = t; }
                    var ahorro = cuenta.GetAhorro(d1, d2);
                    Console.WriteLine($"Ahorro del período: {ahorro.ToString("N2", new CultureInfo("es-ES"))}€");
                }
                else if (opcion == "8")
                {
                    var d1 = ReadDate("Fecha inicio: ");
                    var d2 = ReadDate("Fecha fin: ");
                    if (d2 < d1) { var t = d1; d1 = d2; d2 = t; }
                    var total = cuenta.GetGastosImprescindibles(d1, d2);
                    Console.WriteLine($"Gastos imprescindibles del período: {total.ToString("N2", new CultureInfo("es-ES"))}€");
                }
                else if (opcion == "9")
                {
                    var posible = cuenta.GetPosiblesAhorrosMesPasado();
                    Console.WriteLine($"Posibles ahorros del mes pasado: {posible.ToString("N2", new CultureInfo("es-ES"))}€");
                }
                else if (opcion == "10")
                {
                    Console.WriteLine("1 Ver lista  2 Añadir producto");
                    var t = Prompt("Elige: ");
                    if (t == "1")
                    {
                        var prods = wishlist.GetProductos();
                        if (prods.Count == 0) Console.WriteLine("Lista vacía.");
                        foreach (var p in prods) Console.WriteLine(p.ToString());
                    }
                    else if (t == "2")
                    {
                        var n = Prompt("Nombre: ");
                        var pr = ReadMoney("Precio: ");
                        var d = Prompt("Descripción: ");
                        wishlist.AddProducto(new Producto(n, pr, d));
                        Console.WriteLine("Producto añadido a la wishlist.");
                    }
                    else
                    {
                        Console.WriteLine("Opción no válida.");
                    }
                }
                else if (opcion == "11")
                {
                    var comprables = wishlist.GetProductosParaComprar();
                    if (comprables.Count == 0) Console.WriteLine("No hay productos que puedas comprar ahora mismo conservando margen para imprescindibles del mes siguiente.");
                    foreach (var p in comprables) Console.WriteLine(p.ToString());
                }
                else if (opcion == "0")
                {
                    Console.WriteLine("Fin del programa. Gracias por utilizar la aplicación.");
                    break;
                }
                else
                {
                    Console.WriteLine("Opción no válida.");
                }
            }
        }
    
}
