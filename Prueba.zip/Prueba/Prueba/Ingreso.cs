﻿using System;
using System.Globalization;


    public sealed class Ingreso : Dinero
    {
        public DateTime Fecha { get; }

        public Ingreso(decimal cantidad, string descripcion, DateTime? fecha = null) : base(cantidad, descripcion)
        {
            Fecha = fecha ?? DateTime.Now;
        }

        public override string ToString()
        {
            return $"Ingreso: {Descripcion}, +{Cantidad.ToString("N2", new CultureInfo("es-ES"))}€ ({Fecha:yyyy-MM-dd})";
        }
    }

