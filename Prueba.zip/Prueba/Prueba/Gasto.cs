﻿using System;


    public abstract class Gasto : Dinero
    {
        public DateTime Fecha { get; }

        protected Gasto(decimal cantidad, string descripcion, DateTime? fecha = null) : base(cantidad, descripcion)
        {
            Fecha = fecha ?? DateTime.Now;
        }
    }

