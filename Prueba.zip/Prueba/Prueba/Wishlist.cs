﻿using System;
using System.Collections.Generic;
using System.Linq;


    public sealed class Wishlist
    {
        public Usuario Propietario { get; }
        private readonly List<Producto> productos;

        public Wishlist(Usuario propietario)
        {
            Propietario = propietario;
            productos = new List<Producto>();
        }

        public void AddProducto(Producto p)
        {
            productos.Add(p);
        }

        public IReadOnlyList<Producto> GetProductos()
        {
            return productos.AsReadOnly();
        }

        public List<Producto> GetProductosParaComprar()
        {
            var cuenta = Propietario.Cuenta;
            if (cuenta == null) return new List<Producto>();
            var hoy = DateTime.Now;
            var inicioMes = new DateTime(hoy.Year, hoy.Month, 1, 0, 0, 0);
            var finMes = new DateTime(hoy.Year, hoy.Month, DateTime.DaysInMonth(hoy.Year, hoy.Month), 23, 59, 59);
            var imprescindiblesActual = cuenta.GetGastosImprescindibles(inicioMes, finMes);
            var presupuesto = cuenta.Saldo - imprescindiblesActual;
            if (presupuesto <= 0) return new List<Producto>();
            return productos.Where(p => p.Precio <= presupuesto).ToList();
        }
    }

