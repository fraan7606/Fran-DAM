﻿using System;


    public abstract class Dinero
    {
        public decimal Cantidad { get; }
        public string Descripcion { get; }

        protected Dinero(decimal cantidad, string descripcion)
        {
            Cantidad = cantidad;
            Descripcion = descripcion;
        }

        public abstract override string ToString();
    }

