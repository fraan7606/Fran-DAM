﻿using System;
using System.Globalization;


    public sealed class GastoBasico : Gasto
    {
        public GastoBasico(decimal cantidad, string descripcion, DateTime? fecha = null) : base(cantidad, descripcion, fecha) { }

        public override string ToString()
        {
            return $"Gasto básico: {Descripcion}, -{Cantidad.ToString("N2", new CultureInfo("es-ES"))}€ ({Fecha:yyyy-MM-dd})";
        }
    }

