﻿using System;



    public sealed class GastoException : Exception
    {
        public GastoException(string message = "Saldo insuficiente para realizar el gasto.") : base(message) { }
    }

