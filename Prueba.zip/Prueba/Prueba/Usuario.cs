﻿using System;
using System.Text.RegularExpressions;


    public sealed class Usuario
    {
        public string Nombre { get; }
        public int Edad { get; }
        public string Dni { get; private set; }
        public Cuenta Cuenta { get; private set; }

        public Usuario(string nombre, int edad)
        {
            Nombre = nombre;
            Edad = edad;
            Dni = null;
            Cuenta = null;
        }

        public bool SetDni(string dni)
        {
            var ok = Regex.IsMatch(dni ?? string.Empty, @"^\d{8}-?[A-Z]$");
            if (ok) Dni = dni.Replace("-", "");
            return ok;
        }

        public void SetCuenta(Cuenta cuenta)
        {
            Cuenta = cuenta;
        }

        public override string ToString()
        {
            return $"Nombre: {Nombre}, Edad: {Edad}, DNI: {Dni}";
        }
    }

