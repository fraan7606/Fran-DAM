﻿using System;
using System.Collections.Generic;
using System.Linq;



    public sealed class Cuenta
    {
        public Usuario Usuario { get; }
        public decimal Saldo { get; private set; }
        private readonly List<object> movimientos;

        public Cuenta(Usuario usuario)
        {
            Usuario = usuario;
            Saldo = 0m;
            movimientos = new List<object>();
        }

        public decimal AddIngreso(decimal cantidad, string descripcion)
        {
            var ingreso = new Ingreso(cantidad, descripcion);
            movimientos.Add(ingreso);
            Saldo += cantidad;
            return Saldo;
        }

        public decimal AddGastoBasico(decimal cantidad, string descripcion)
        {
            if (cantidad > Saldo) throw new GastoException();
            var gasto = new GastoBasico(cantidad, descripcion);
            movimientos.Add(gasto);
            Saldo -= cantidad;
            return Saldo;
        }

        public decimal AddGastoExtra(decimal cantidad, string descripcion, bool prescindible)
        {
            if (cantidad > Saldo) throw new GastoException();
            var gasto = new GastoExtra(cantidad, descripcion, prescindible);
            movimientos.Add(gasto);
            Saldo -= cantidad;
            return Saldo;
        }

        public List<GastoBasico> GetGastosBasicos(bool esteMes)
        {
            var hoy = DateTime.Now;
            return movimientos
                .OfType<GastoBasico>()
                .Where(g => !esteMes || (g.Fecha.Year == hoy.Year && g.Fecha.Month == hoy.Month))
                .OrderBy(g => g.Fecha)
                .ToList();
        }

        public List<GastoExtra> GetGastosExtras(bool esteMes)
        {
            var hoy = DateTime.Now;
            return movimientos
                .OfType<GastoExtra>()
                .Where(g => !esteMes || (g.Fecha.Year == hoy.Year && g.Fecha.Month == hoy.Month))
                .OrderBy(g => g.Fecha)
                .ToList();
        }

        public List<Ingreso> GetIngresos(bool esteMes)
        {
            var hoy = DateTime.Now;
            return movimientos
                .OfType<Ingreso>()
                .Where(i => !esteMes || (i.Fecha.Year == hoy.Year && i.Fecha.Month == hoy.Month))
                .OrderBy(i => i.Fecha)
                .ToList();
        }

        public decimal GetAhorro(DateTime desde, DateTime hasta)
        {
            var ingresos = movimientos.OfType<Ingreso>().Where(m => m.Fecha >= desde && m.Fecha <= hasta).Sum(m => m.Cantidad);
            var gastos = movimientos.OfType<Gasto>().Where(m => m.Fecha >= desde && m.Fecha <= hasta).Sum(m => m.Cantidad);
            return ingresos - gastos;
        }

        public decimal GetGastosImprescindibles(DateTime desde, DateTime hasta)
        {
            var basicos = movimientos.OfType<GastoBasico>().Where(m => m.Fecha >= desde && m.Fecha <= hasta).Sum(m => m.Cantidad);
            var extrasNoPresc = movimientos.OfType<GastoExtra>().Where(m => m.Fecha >= desde && m.Fecha <= hasta && !m.Prescindible).Sum(m => m.Cantidad);
            return basicos + extrasNoPresc;
        }

        public decimal GetPosiblesAhorrosMesPasado()
        {
            var firstThisMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            var inicio = firstThisMonth.AddMonths(-1);
            var fin = firstThisMonth.AddSeconds(-1);
            return movimientos
                .OfType<GastoExtra>()
                .Where(m => m.Prescindible && m.Fecha >= inicio && m.Fecha <= fin)
                .Sum(m => m.Cantidad);
        }

        public IReadOnlyList<object> GetMovimientos()
        {
            return movimientos.AsReadOnly();
        }
    }

