﻿using System;
using System.Globalization;


    public sealed class Producto
    {
        public string Nombre { get; }
        public decimal Precio { get; }
        public string Descripcion { get; }

        public Producto(string nombre, decimal precio, string descripcion)
        {
            Nombre = nombre;
            Precio = precio;
            Descripcion = descripcion;
        }

        public override string ToString()
        {
            return $"{Nombre} - {Precio.ToString("N2", new CultureInfo("es-ES"))}€";
        }
    }

